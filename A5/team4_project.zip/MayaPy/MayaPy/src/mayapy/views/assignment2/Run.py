# Run.py
# Honglu Xu

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class Run(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(Run, self).__init__(parent, **kwargs)
        self.ok_but.clicked.connect(self._handleok_but)
        self.return_but.clicked.connect(self._handle_retu_but)

#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome
    def _handle_retu_but(self):
        self.mainWindow.setActiveWidget('assignment2')

    def _handleok_but(self):

        cmds.select( 'body', visible=True )

        temp_star_time = self.star_time_text.text()
        try:
            star_time = int(temp_star_time)
        except ValueError:
            star_time = 1
        temp_run_time = self.run_time_text.text()
        try:
            run_time = int(temp_run_time)
        except ValueError:
            run_time = 50
        temp_star_z = self.star_z_text.text()
        try:
            star_z = float(temp_star_z)
        except ValueError:
            star_z = -50
        temp_end_z = self.end_z_text.text()
        try:
            end_z = float(temp_end_z)
        except ValueError:
            end_z = -2
        temp_jump_heig = self.jump_heig_text.text()
        try:
            jump_heig = float(temp_jump_heig)
        except ValueError:
            jump_heig = 2
        temp_jump_times = self.jump_time_text.text()
        try:
            jump_times = int(temp_jump_times)
        except ValueError:
            jump_times = 10
        temp_arms_spin = self.arms_spin_text.text()
        try:
            arms_spin = int(temp_arms_spin)
        except ValueError:
            arms_spin = 50
        temp_legs_spin = self.legs_spin_text.text()
        try:
            legs_spin = int(temp_legs_spin)
        except ValueError:
            legs_spin = 30

        #time = float(star_time)
        cmds.currentTime( star_time, edit=True )
        cmds.setAttr( 'body.translateZ', star_z )
        cmds.setAttr( 'body.translateY', 0 )
        cmds.setKeyframe(attribute='translateY')
        cmds.setKeyframe(attribute='translateZ')
        #cmds.keyTangent( time=('10.0','10.0'), attribute='translateZ',inTangentType='linear',outTangentType='linear')
        #cmds.keyTangent( 'body', edit=True, time=(120,120), attribute='translateY', absolute=True,inTangentType='linear',outTangentType='linear')
        #1#

        cmds.currentTime( star_time+run_time, edit=True )
        cmds.setAttr( 'body.translateZ', end_z )
        cmds.setKeyframe(attribute='translateZ')
        #cmds.keyTangent( 'body', edit=True, time=(240,240), attribute='translateZ', absolute=True,inTangentType='linear',outTangentType='linear')
        #run_rime#

        jump_dura = run_time / jump_times
        time = star_time
        for i in range(0,jump_times) :
            time = time + jump_dura
            cmds.currentTime( time, edit=True )
            cmds.setAttr( 'body.translateY', 0 )
            cmds.setKeyframe(attribute='translateY')
            #cmds.keyTangent( 'body', edit=True, time=(time,time), attribute='translateY', absolute=True,inTangentType='linear',outTangentType='linear')
            time2 = time - jump_dura/2
            cmds.currentTime( time2, edit=True )
            cmds.setAttr( 'body.translateY', jump_heig )
            cmds.setKeyframe(attribute='translateY')


        cmds.select( 'arm_L', visible=True )

        cmds.currentTime( star_time, edit=True )
        cmds.setAttr( 'arm_L.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #cmds.keyTangent( 'arm_L', edit=True, time=(120,120), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
        #1#

        time = star_time
        for i in range(0,jump_times) :
            time = time + jump_dura
            cmds.currentTime( time, edit=True )
            cmds.setAttr( 'arm_L.rotateX', 0 )
            cmds.setKeyframe(attribute='rotateX')
            #cmds.keyTangent( 'arm_L', edit=True, time=(time,time), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
            time2 = time - jump_dura/2
            cmds.currentTime( time2, edit=True )
            cmds.setAttr( 'arm_L.rotateX', arms_spin )
            print arms_spin, "1"
            cmds.setKeyframe(attribute='rotateX')
            arms_spin = -arms_spin

        arms_spin = abs(arms_spin)
        #L_arm#

        cmds.select( 'arm_R', visible=True )

        time = star_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'arm_R.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #cmds.keyTangent( 'arm_R', edit=True, time=(120,120), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
        #1#

        #temp_time = 120

        for j in range(0,jump_times) :
            time = time + jump_dura
            cmds.currentTime( time, edit=True )
            cmds.setAttr( 'arm_R.rotateX', 0 )
            cmds.setKeyframe(attribute='rotateX')
            #cmds.keyTangent( 'arm_R', edit=True, time=(time,time), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
            time2 = time - jump_dura/2
            arms_spin = -arms_spin
            cmds.currentTime( time2, edit=True )
            cmds.setAttr( 'arm_R.rotateX', arms_spin )
            print arms_spin, "2"
            cmds.setKeyframe(attribute='rotateX')

        arms_spin = abs(arms_spin)
        #R_arm#

        cmds.select( 'left_L', visible=True )
        time = star_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'left_L.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #cmds.keyTangent( 'left_L', edit=True, time=(120,120), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
        #1#

        #temp_time = 120

        for i in range(0,jump_times) :
            time = time + jump_dura
            cmds.currentTime( time, edit=True )
            cmds.setAttr( 'left_L.rotateX', 0 )
            cmds.setKeyframe(attribute='rotateX')
            #cmds.keyTangent( 'left_L', edit=True, time=(time,time), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
            time2 = time - jump_dura/2
            legs_spin = -legs_spin
            cmds.currentTime( time2, edit=True )
            cmds.setAttr( 'left_L.rotateX', legs_spin )
            cmds.setKeyframe(attribute='rotateX')

        legs_spin = abs(legs_spin)
        #L_leg#

        cmds.select( 'leg_R', visible=True )
        time = star_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'leg_R.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #cmds.keyTangent( 'leg_R', edit=True, time=(120,120), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
        #1#

        for i in range(0,jump_times) :
            time = time + jump_dura
            cmds.currentTime( time, edit=True )
            cmds.setAttr( 'leg_R.rotateX', 0 )
            cmds.setKeyframe(attribute='rotateX')
            #cmds.keyTangent( 'leg_R', edit=True, time=(time,time), attribute='rotateX', absolute=True,inTangentType='linear',outTangentType='linear')
            time2 = time - jump_dura/2
            cmds.currentTime( time2, edit=True )
            cmds.setAttr( 'leg_R.rotateX', legs_spin )
            cmds.setKeyframe(attribute='rotateX')
            legs_spin = -legs_spin

        legs_spin = abs(legs_spin)
        #R_leg#






