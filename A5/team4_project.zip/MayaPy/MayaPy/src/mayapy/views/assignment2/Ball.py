# Ball.py
# Honglu Xu

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class Ball(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(Ball, self).__init__(parent, **kwargs)
        self.ok_but.clicked.connect(self._handleok_but)
        self.return_but.clicked.connect(self._handle_retu_but)

#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome
    def _handle_retu_but(self):
        self.mainWindow.setActiveWidget('assignment2')

    def _handleok_but(self):

        cmds.select( 'ball', visible=True )

        #initial_time = 75
        #initial_tran = 0
        #velocity = 50
        #height = 10
        #temp_time = 75
        #time = 0
        #time_l = [1,2,3]

        temp_star_time = self.star_time_text.text()
        try:
            star_time = int(temp_star_time)
        except ValueError:
            star_time = 1
        temp_boun_time = self.boun_time_text.text()
        try:
            boun_time = int(temp_boun_time)
        except ValueError:
            boun_time = 3
        temp_firs_dist = self.firs_dist_time.text()
        try:
            firs_dist = int(temp_firs_dist)
        except ValueError:
            firs_dist = 20
        temp_firs_time = self.firs_time_text.text()
        try:
            firs_time = int(temp_firs_time)
        except ValueError:
            firs_time = 10
        temp_dist_deca = self.deca_text.text()
        try:
            dist_deca = int(temp_dist_deca)
        except ValueError:
            dist_deca = 50
        temp_firs_heig = self.firs_heig_text.text()
        try:
            firs_heig = int(temp_firs_heig)
        except ValueError:
            firs_heig = 10
        temp_firs_spin = self.spin_angl_text.text()
        try:
            firs_spin = int(temp_firs_spin)
        except ValueError:
            firs_spin = 300
        spin_way = self.spin_dire_comb.currentIndex()
        #print spin_way, " spin_way"

        heig_deca = dist_deca / 2.0
        time_deca = heig_deca
        dist_deca = dist_deca/100.0
        time_deca = time_deca/100.0
        heig_deca = heig_deca/100.0
        dist_mult = 1.0 - dist_deca
        heig_mult = 1.0 - heig_deca
        time_mult = 1.0 - time_deca
        spin_mult = time_mult

        time = star_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'ball.translateZ', 0 )
        cmds.setAttr( 'ball.translateY', 0.5 )
        cmds.setAttr( 'ball.rotateX', 0 )
        cmds.setAttr( 'ball.rotateY', 0 )
        cmds.setAttr( 'ball.rotateZ', 0 )
        cmds.setKeyframe(attribute='translateY')
        cmds.setKeyframe(attribute='translateZ')
        cmds.setKeyframe(attribute='rotateY')
        cmds.setKeyframe(attribute='rotateZ')
        cmds.setKeyframe(attribute='rotateX')
        #cmds.keyTangent( 'ball', edit=True, time=(10,10), attribute='translateZ',inTangentType='linear',outTangentType='linear')
        #cmds.keyTangent( 'ball', edit=True, time=(10,10), attribute='translateY',inTangentType='linear',outTangentType='linear')
        #1#

        time_trav = firs_time
        tran_z = 0
        dist_trav = firs_dist
        height = firs_heig
        turn = firs_spin
        angle = 0
        for i in range(0,boun_time):
            time = time + time_trav
            #print time," time!!"
            cmds.currentTime( time, edit=True )
            tran_z = tran_z + dist_trav
            #print tran_z," tran_z"
            cmds.setAttr( 'ball.translateZ', tran_z )
            cmds.setKeyframe(attribute='translateZ')
            cmds.setAttr( 'ball.translateY', 0 )
            cmds.setKeyframe(attribute='translateY')
            angle = angle + turn
            print turn, "turn"
            print angle, "angle"
            cmds.setAttr( 'ball.rotateX', angle )
            cmds.setAttr( 'ball.rotateY', angle )
            cmds.setAttr( 'ball.rotateZ', angle )
            cmds.setKeyframe(attribute='rotateY')
            cmds.setKeyframe(attribute='rotateZ')
            cmds.setKeyframe(attribute='rotateX')

            time2 = time - time_trav/2
            cmds.currentTime( time2, edit=True )
            cmds.setAttr( 'ball.translateY', height )
            cmds.setKeyframe(attribute='translateY')

            time_trav = time_trav * time_mult
            dist_trav = dist_trav * dist_mult
            height = height * heig_mult
            turn = turn * spin_mult
            if spin_way == 1:
                turn = -turn






