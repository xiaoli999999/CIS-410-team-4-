# Arm_Raise.py
# Honglu Xu

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class Arm_Raise(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(Arm_Raise, self).__init__(parent, **kwargs)
        self.ok_but.clicked.connect(self._handleok_but)
        #self.dele_but.clicked.connect(self._handledele_but)
        self.return_but.clicked.connect(self._handle_reut_but)



#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome
    def _handle_reut_but(self):
        self.mainWindow.setActiveWidget('assignment2')

    #def _handledele_but(self):
        #print 1

    def _handleok_but(self):
        cmds.select( 'arm_R', visible=True )

        temp_star_fram = self.star_fram_text.text()
        try:
            star_fram = int(temp_star_fram)
        except ValueError:
            star_fram = 1
        temp_rais_time = self.rais_time_text.text()
        try:
            rais_time = int(temp_rais_time)
        except ValueError:
            rais_time = 10
        temp_rais_angl = self.rais_angl_text.text()
        try:
            rais_angl = int(temp_rais_angl)
        except ValueError:
            rais_angl = 160
        temp_paus_time = self.paus_time_text.text()
        try:
            paus_time = int(temp_paus_time)
        except ValueError:
            paus_time = 10

        time = star_fram
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'arm_R.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #1#

        time = time + rais_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'arm_R.rotateX', -rais_angl )
        cmds.setKeyframe(attribute='rotateX')
        #raise_time#

        time = time + paus_time
        cmds.currentTime( time, edit=True )
        cmds.setKeyframe(attribute='rotateX')
        #raise_time+pause_time#

        time = time + 10
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'arm_R.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #10+raise_time+pause_time#