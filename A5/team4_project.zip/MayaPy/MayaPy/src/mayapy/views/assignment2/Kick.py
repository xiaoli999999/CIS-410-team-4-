# Kick.py
# Honglu Xu

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class Kick(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(Kick, self).__init__(parent, **kwargs)
        self.ok_but.clicked.connect(self._handleok_but)
        self.return_but.clicked.connect(self._handlereturn_but)

#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome
    def _handlereturn_but(self):
        self.mainWindow.setActiveWidget('assignment2')

    def _handleok_but(self):
        cmds.select( 'leg_R', visible=True )

        temp_star_fram = self.star_fram_text.text()
        try:
            star_fram = int(temp_star_fram)
        except ValueError:
            star_fram = 1
        temp_prep_time = self.prep_time_text.text()
        try:
            prep_time = int(temp_prep_time)
        except ValueError:
            prep_time = 10
        temp_back_angle = self.back_angle_text.text()
        try:
            back_angle = int(temp_back_angle)
        except ValueError:
            back_angle = 50
        temp_kick_time = self.kick_time_text.text()
        try:
            kick_time = int(temp_kick_time)
        except ValueError:
            kick_time = 10
        temp_kick_angle = self.turn_angle_text.text()
        try:
            kick_angle = int(temp_kick_angle)
        except ValueError:
            kick_angle = 60
        temp_pause_time = self.pause_time_text.text()
        try:
            pause_time = int(temp_pause_time)
        except ValueError:
            pause_time = 10

        time = star_fram
        cmds.currentTime( star_fram, edit=True )
        cmds.setAttr( 'leg_R.rotateX', 0)
        cmds.setKeyframe(attribute='rotateX')
        #1#

        time = time+prep_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'leg_R.rotateX', back_angle)
        cmds.setKeyframe(attribute='rotateX')
        #prep_time#

        time = time+kick_time
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'leg_R.rotateX', -kick_angle )
        cmds.setKeyframe(attribute='rotateX')
        #prep_time+kick#

        time = time+pause_time
        cmds.currentTime( time, edit=True )
        cmds.setKeyframe(attribute='rotateX')
        #prep_time+kick+pause#

        time = time+10
        cmds.currentTime( time, edit=True )
        cmds.setAttr( 'leg_R.rotateX', 0 )
        cmds.setKeyframe(attribute='rotateX')
        #10+prep_time+kick+pause#
