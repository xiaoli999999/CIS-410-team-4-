from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class smile2(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(smile2, self).__init__(parent, **kwargs)
        self.previousButton.clicked.connect(self._handle_previous_but)
        self.homeButton.clicked.connect(self._handle_home_but)
        self.hSlider1.valueChanged.connect(self._handleSlider1)
        self.hSlider2.valueChanged.connect(self._handleSlider2)
        self.hSlider3.valueChanged.connect(self._handleSlider3)
        self.hSlider4.valueChanged.connect(self._handleSlider4)
        self.lineEdit_1.textChanged.connect(self._handleLineEdit1)
        self.lineEdit_2.textChanged.connect(self._handleLineEdit2)
        self.lineEdit_3.textChanged.connect(self._handleLineEdit3)
        self.lineEdit_4.textChanged.connect(self._handleLineEdit4)
        self.lineEdit_1.setText("50")
        self.lineEdit_2.setText("50")
        self.lineEdit_3.setText("50")
        self.lineEdit_4.setText("50")
        self.hSlider1.setValue(50)
        self.hSlider2.setValue(50)
        self.hSlider3.setValue(50)
        self.hSlider4.setValue(50)
#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome

    def _handle_previous_but(self):
        self.mainWindow.setActiveWidget('smile')

    def _handle_home_but(self):
        self.mainWindow.setActiveWidget('home')

    def _handleSlider1(self):
        value = self.hSlider1.value()
        self.lineEdit_1.setText(str(value))

    def _handleSlider2(self):
        value = self.hSlider2.value()
        self.lineEdit_2.setText(str(value))

    def _handleSlider3(self):
        value = self.hSlider3.value()
        self.lineEdit_3.setText(str(value))

    def _handleSlider4(self):
        value = self.hSlider4.value()
        self.lineEdit_4.setText(str(value))
        
    # head high
    def _handleLineEdit1(self):
        try:
            value = int(self.lineEdit_1.text())
        except ValueError:
            value = 0.0

        if value < 0.0:
            value = 0.0
            self.lineEdit_1.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_1.setText("99")

        headHighMax = 0.4
        headHighMax = (float(value) - 50) * float(headHighMax) / 50

        cmds.setAttr('high1.translateY',headHighMax)
        cmds.setAttr('high2.translateY',headHighMax)
        cmds.setAttr('high3.translateY',headHighMax)
    # face width
    def _handleLineEdit2(self):
        try:
            value = int(self.lineEdit_2.text())
        except ValueError:
            value = 0.0

        if value < 0.0:
            value = 0.0
            self.lineEdit_2.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_2.setText("99")

        faceWidthMax = 0.12
        faceWidthMax = (float(value) - 50) * float(faceWidthMax) / 50

        cmds.setAttr('face_wide1.translateX',faceWidthMax)
        cmds.setAttr('face_wide2.translateX',faceWidthMax)
        cmds.setAttr('face_wide3.translateX',faceWidthMax)
    # chin size
    def _handleLineEdit3(self):
        try:
            value = int(self.lineEdit_3.text())
        except ValueError:
            value = 0.0

        if value < 0.0:
            value = 0.0
            self.lineEdit_3.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_3.setText("99")

        chinSizehMax = 0.1
        chinSizehMax = (float(value) - 50) * float(chinSizehMax) / 50

        cmds.setAttr('chin1.translateX',chinSizehMax)
        cmds.setAttr('chin2.translateX',chinSizehMax)
        cmds.setAttr('chin3.translateX',chinSizehMax)
        cmds.setAttr('chin4.translateX',chinSizehMax)
    # nose size
    def _handleLineEdit4(self):
        try:
            value = int(self.lineEdit_4.text())
        except ValueError:
            value = 0.0

        if value < 0.0:
            value = 0.0
            self.lineEdit_4.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_4.setText("99")

        noseSizehMax = 0.15
        noseSizehMax = (float(value) - 50) * float(noseSizehMax) / 50

        cmds.setAttr('nose_high1.translateZ',noseSizehMax)
        cmds.setAttr('nose_wide_high1.translateX',noseSizehMax)
        cmds.setAttr('nose_wide_high1.translateZ',noseSizehMax)
        cmds.setAttr('nose_up_high1.translateY',noseSizehMax)
        cmds.setAttr('nose_up_high1.translateZ',noseSizehMax)
        cmds.setAttr('nose_wide_high2.translateX',noseSizehMax)
        cmds.setAttr('nose_wide_high2.translateZ',noseSizehMax)

