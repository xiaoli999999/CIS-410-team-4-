# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\leili\PycharmProjects\hongluxu\MayaPy\MayaPy\resources\widget\smile\Widget.ui'
#
# Created: Mon Nov 23 21:21:37 2015
#      by: pyside-uic 0.2.15 running on PySide 1.2.2
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class PySideUiFileSetup(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(608, 422)
        Form.horizontalLayoutWidget = QtGui.QWidget(Form)
        Form.horizontalLayoutWidget.setGeometry(QtCore.QRect(30, 30, 541, 361))
        Form.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        Form.horizontalLayout = QtGui.QHBoxLayout(Form.horizontalLayoutWidget)
        Form.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        Form.horizontalLayout.setObjectName("horizontalLayout")
        Form.horizontalLayout_2 = QtGui.QHBoxLayout()
        Form.horizontalLayout_2.setObjectName("horizontalLayout_2")
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        Form.horizontalLayout_2.addItem(spacerItem)
        Form.horizontalSlider = QtGui.QSlider(Form.horizontalLayoutWidget)
        Form.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
        Form.horizontalSlider.setObjectName("horizontalSlider")
        Form.horizontalLayout_2.addWidget(Form.horizontalSlider)
        Form.horizontalLayout.addLayout(Form.horizontalLayout_2)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        Form.horizontalLayout.addItem(spacerItem1)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(QtGui.QApplication.translate("Form", "Form", None, QtGui.QApplication.UnicodeUTF8))

