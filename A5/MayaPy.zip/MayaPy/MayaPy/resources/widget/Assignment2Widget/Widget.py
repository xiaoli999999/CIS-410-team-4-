# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\leili\PycharmProjects\hongluxu\MayaPy\MayaPy\resources\widget\Assignment2Widget\Widget.ui'
#
# Created: Mon Nov 23 21:21:35 2015
#      by: pyside-uic 0.2.15 running on PySide 1.2.2
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class PySideUiFileSetup(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(608, 422)
        Form.horizontalLayout = QtGui.QHBoxLayout(Form)
        Form.horizontalLayout.setObjectName("horizontalLayout")
        Form.controlsBox = QtGui.QWidget(Form)
        Form.controlsBox.setObjectName("controlsBox")
        Form.verticalLayout = QtGui.QVBoxLayout(Form.controlsBox)
        Form.verticalLayout.setContentsMargins(0, 0, 0, 0)
        Form.verticalLayout.setObjectName("verticalLayout")
        Form.label = QtGui.QLabel(Form.controlsBox)
        Form.label.setObjectName("label")
        Form.verticalLayout.addWidget(Form.label)
        Form.Kick = QtGui.QPushButton(Form.controlsBox)
        Form.Kick.setObjectName("Kick")
        Form.verticalLayout.addWidget(Form.Kick)
        Form.arm_rais_but = QtGui.QPushButton(Form.controlsBox)
        Form.arm_rais_but.setObjectName("arm_rais_but")
        Form.verticalLayout.addWidget(Form.arm_rais_but)
        Form.ball_but = QtGui.QPushButton(Form.controlsBox)
        Form.ball_but.setObjectName("ball_but")
        Form.verticalLayout.addWidget(Form.ball_but)
        Form.run_but = QtGui.QPushButton(Form.controlsBox)
        Form.run_but.setObjectName("run_but")
        Form.verticalLayout.addWidget(Form.run_but)
        Form.homeBtn = QtGui.QPushButton(Form.controlsBox)
        Form.homeBtn.setObjectName("homeBtn")
        Form.verticalLayout.addWidget(Form.homeBtn)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        Form.verticalLayout.addItem(spacerItem)
        Form.horizontalLayout.addWidget(Form.controlsBox)
        spacerItem1 = QtGui.QSpacerItem(439, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        Form.horizontalLayout.addItem(spacerItem1)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(QtGui.QApplication.translate("Form", "Form", None, QtGui.QApplication.UnicodeUTF8))
        Form.label.setText(QtGui.QApplication.translate("Form", "Assignment 2", None, QtGui.QApplication.UnicodeUTF8))
        Form.Kick.setText(QtGui.QApplication.translate("Form", "Kick", None, QtGui.QApplication.UnicodeUTF8))
        Form.arm_rais_but.setText(QtGui.QApplication.translate("Form", "Arm Raise", None, QtGui.QApplication.UnicodeUTF8))
        Form.ball_but.setText(QtGui.QApplication.translate("Form", "Ball", None, QtGui.QApplication.UnicodeUTF8))
        Form.run_but.setText(QtGui.QApplication.translate("Form", "Run", None, QtGui.QApplication.UnicodeUTF8))
        Form.homeBtn.setText(QtGui.QApplication.translate("Form", "Return Home", None, QtGui.QApplication.UnicodeUTF8))

