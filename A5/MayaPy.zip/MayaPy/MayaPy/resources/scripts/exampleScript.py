import math

import nimble
from nimble import cmds

#cmds.doSomethingHere

response = nimble.createRemoteResponse(globals())
response.put('name', c)
