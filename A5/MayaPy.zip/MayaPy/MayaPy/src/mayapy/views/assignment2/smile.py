# Run.py
# Honglu Xu

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class smile(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(smile, self).__init__(parent, **kwargs)
        self.hSlider1.valueChanged.connect(self._handleSlider1)
        self.hSlider2.valueChanged.connect(self._handleSlider2)

#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome

    def _handleSlider1(self):
        maxSmile = 0.116
        minSmile = 0
        value = self.hSlider1.value()
        #== self.hSlider1.setValue(50)
        smileValue = float(value) * float(maxSmile/100.0)
        #
        cmds.setAttr('cluster1Handle.translateY',smileValue)
        cmds.setAttr('cluster2Handle.translateY',smileValue)
        cmds.setAttr('cluster3Handle.translateY',smileValue)


    def _handleSlider2(self):
        value = self.hSlider2.value()
        min = 0
        smile_eye1MaxY = -0.1
        smile_eye2MaxY = 0.178
        smile_eye3MaxY = 0.05
        smile_eye4MaxY = 0.089
        smile_eye5MaxX = -0.2
        smile_eye5MaxY = -0.1
        smile_eye6MaxX = 0.2
        smile_eye6MaxY = -0.1

        cmds.setAttr('smile_eye1.translateY',float(value) * float(smile_eye1MaxY/100))
        cmds.setAttr('smile_eye2.translateY',float(value) * float(smile_eye2MaxY/100))
        cmds.setAttr('smile_eye3.translateY',float(value) * float(smile_eye3MaxY/100))
        cmds.setAttr('smile_eye4.translateY',float(value) * float(smile_eye4MaxY/100))
        cmds.setAttr('smile_eye5.translateX',float(value) * float(smile_eye5MaxX/100))
        cmds.setAttr('smile_eye5.translateY',float(value) * float(smile_eye5MaxY/100))
        cmds.setAttr('smile_eye6.translateX',float(value) * float(smile_eye6MaxX/100))
        cmds.setAttr('smile_eye6.translateY',float(value) * float(smile_eye6MaxY/100))






