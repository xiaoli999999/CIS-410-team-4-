MayaPy
======

A framework for the class CIS 410/510 Graphical Programming in Python; K.A. Stevens, instructor
