# Run.py
# Lei Li

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class smile(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(smile, self).__init__(parent, **kwargs)
        self.hSlider1.valueChanged.connect(self._handleSlider1)
        self.hSlider2.valueChanged.connect(self._handleSlider2)
        self.hSlider3.valueChanged.connect(self._handleSlider3)
        self.hSlider4.valueChanged.connect(self._handleSlider4)
        self.hSlider5.valueChanged.connect(self._handleSlider5)

        self.nextButton.clicked.connect(self._handle_next_but)
        self.homeButton.clicked.connect(self._handle_home_but)
        self.setKeyButton.clicked.connect(self._handle_set_key_but)

        self.lineEdit_1.textChanged.connect(self._handleLineEdit1)
        self.lineEdit_2.textChanged.connect(self._handleLineEdit2)
        self.lineEdit_3.textChanged.connect(self._handleLineEdit3)
        self.lineEdit_4.textChanged.connect(self._handleLineEdit4)
        self.lineEdit_5.textChanged.connect(self._handleLineEdit5)

        self.lineEdit_1.setText("0")
        self.lineEdit_2.setText("0")
        self.lineEdit_3.setText("0")
        self.lineEdit_4.setText("0")
        self.lineEdit_5.setText("0")


#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome

    def _handle_next_but(self):
        self.mainWindow.setActiveWidget('smile2')

    def _handle_home_but(self):
        self.mainWindow.setActiveWidget('home')

    def _handleSlider1(self):
        value = self.hSlider1.value()
        self.lineEdit_1.setText(str(value))

    def _handleSlider2(self):
        value = self.hSlider2.value()
        self.lineEdit_2.setText(str(value))

    def _handleSlider3(self):
        value = self.hSlider3.value()
        self.lineEdit_3.setText(str(value))

    def _handleSlider4(self):
        value = self.hSlider4.value()
        self.lineEdit_4.setText(str(value))

    def _handleSlider5(self):
        value = self.hSlider5.value()
        self.lineEdit_5.setText(str(value))


    def _handleLineEdit1(self):
        maxSmileX = 0.1
        maxSmileY = 0.15
        try:
            value = int(self.lineEdit_1.text())
        except ValueError:
            value = 0.0

        if value < 0.0:
            value = 0.0
            self.lineEdit_1.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_1.setText("99")
        self.hSlider1.setValue(value)
        smileValueX = float(value) * float(maxSmileX/100.0)
        smileValueY = float(value) * float(maxSmileY/100.0)

        cmds.setAttr('cluster10Handle.translateX',smileValueX)
        cmds.setAttr('cluster11Handle.translateX',smileValueX)
        cmds.setAttr('cluster13Handle.translateX',smileValueX)
        cmds.setAttr('cluster14Handle.translateX',smileValueX)
        cmds.setAttr('cluster15Handle.translateX',smileValueX)

        cmds.setAttr('cluster10Handle.translateY',smileValueY)
        cmds.setAttr('cluster11Handle.translateY',smileValueY)
        cmds.setAttr('cluster13Handle.translateY',smileValueY)
        cmds.setAttr('cluster14Handle.translateY',smileValueY)
        cmds.setAttr('cluster15Handle.translateY',smileValueY)

    #smile of eyes
    def _handleLineEdit2(self):
        try:
            value = int(self.lineEdit_2.text())
        except ValueError:
            value = 0.0
        if value < 0.0:
            value = 0.0
            self.lineEdit_2.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_2.setText("99")
        self.hSlider2.setValue(value)
        eye_wide1XMax = 0.1
        eye_wide2XMax = -0.1
        eye_downY = -0.07
        eye_upY = 0.07

        cmds.setAttr('eye_wide1.translateX',float(value) * float(eye_wide1XMax/100))
        cmds.setAttr('eye_wide2.translateX',float(value) * float(eye_wide2XMax/100))
        cmds.setAttr('eye_down1.translateY',float(value) * float(eye_downY/100))
        cmds.setAttr('eye_down2.translateY',float(value) * float(eye_downY/100))
        cmds.setAttr('eye_down3.translateX',float(value) * float(eye_downY/100))
        cmds.setAttr('eye_up1.translateY',float(value) * float(eye_upY/100))
        cmds.setAttr('eye_up2.translateX',float(value) * float(eye_upY/100))
        cmds.setAttr('eye_up3.translateY',float(value) * float(eye_upY/100))

        x0 =  -1.982
        y0 =  -0.223
        z0 =  -0.00396
        x1 =  -1.84
        y1 =  -0.104
        z1 =  -0.0297
        x2 =  -1.632
        y2 =  -0.178
        z2 =  -0.0822
        x3 =  -1.524
        y3 =  -0.221
        z3 =  -0.32

        cmds.setAttr('curve1.cv[0]',x0,float(value) * float(eye_downY)/100 * 0.4 +y0,z0)
        cmds.setAttr('curve1.cv[1]',x1,float(value) * float(eye_downY)/100 * 0.4 +y1,z1)
        cmds.setAttr('curve1.cv[2]',x2,float(value) * float(eye_downY)/100 * 0.4+y2,z2)
        cmds.setAttr('curve1.cv[3]',x3,float(value) * float(eye_downY)/100 * 0.4+y3,z3)

    #eyesbows
    def _handleLineEdit3(self):
        try:
            value = int(self.lineEdit_3.text())
        except ValueError:
            value = 0.0
        if value < 0.0:
            value = 0.0
            self.lineEdit_3.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_3.setText("99")
        self.hSlider3.setValue(value)
        # eyesbows
        x2 =  -1.632
        y2 =  -0.178
        z2 =  -0.0822
        x3 =  -1.524
        y3 =  -0.221
        z3 =  -0.32

        y2Max = -0.075
        y3Max = 0


        cmds.setAttr('curve1.cv[2]',x2,float(value) * float(y2Max-y2)/100+y2,z2)
        cmds.setAttr('curve1.cv[3]',x3,float(value) * float(y3Max-y3)/100+y3,z3)

    #mouth open

    def _handleLineEdit4(self):
        try:
            value = int(self.lineEdit_4.text())
        except ValueError:
            value = 0.0
        if value < 0.0:
            value = 0.0
            self.lineEdit_4.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_4.setText("99")
        self.hSlider4.setValue(value)
        upMax = 0.15
        downMax = -0.15

        upMax = float(value) * float(upMax/100.0)
        downMax = float(value) * float(downMax/100.0)
        cmds.setAttr('mouth_up1.translateY',upMax)
        cmds.setAttr('mouth_up2.translateY',upMax)
        cmds.setAttr('mouth_up3.translateY',upMax)
        cmds.setAttr('mouth_up4.translateY',upMax)
        cmds.setAttr('mouth_up5.translateY',upMax)

        cmds.setAttr('mouth_down1.translateY',downMax)
        cmds.setAttr('mouth_down2.translateY',downMax)
        cmds.setAttr('mouth_down3.translateY',downMax)
        cmds.setAttr('mouth_down4.translateY',downMax)


    #angry of mouth

    def _handleLineEdit5(self):
        try:
            value = int(self.lineEdit_5.text())
        except ValueError:
            value = 0.0
        if value < 0.0:
            value = 0.0
            self.lineEdit_5.setText("0")
        elif value > 99.0:
            value = 99.0
            self.lineEdit_5.setText("99")
        self.hSlider5.setValue(value)
        # mouth
        maxSmileY = - 0.15
        smileValueY = float(value) * float(maxSmileY/100.0)

        cmds.setAttr('cluster10Handle.translateY',smileValueY)
        cmds.setAttr('cluster11Handle.translateY',smileValueY)
        cmds.setAttr('cluster13Handle.translateY',smileValueY)
        cmds.setAttr('cluster14Handle.translateY',smileValueY)
        cmds.setAttr('cluster15Handle.translateY',smileValueY)


    def _handle_set_key_but(self):
        cmds.setKeyframe('cluster10Handle','cluster11Handle','cluster13Handle','cluster14Handle','cluster14Handle',
                         'cluster15Handle','eye_wide1','eye_wide2','eye_down1','eye_up1','eye_down2','eye_up2','eye_down3',
                         'eye_up3','angry_eye1','angry_eye2','face_wide1','face_wide2','face_wide3','high1','high2','high3',
                         'nose_high1','nose_wide_high1','nose_up_high1','nose_wide_high2','chin1','chin2','chin3','chin4',
                         'mouth_up1','mouth_up2','mouth_up3','mouth_up4','mouth_up5','mouth_down1','mouth_down2','mouth_down3',
                         'mouth_down4')
