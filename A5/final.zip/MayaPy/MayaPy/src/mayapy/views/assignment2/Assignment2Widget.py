# Assignment2Widget.py
# (C)2013
# Scott Ernst

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class Assignment2Widget(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(Assignment2Widget, self).__init__(parent, **kwargs)
        self.Kick.clicked.connect(self._handle_kick_but)
        self.homeBtn.clicked.connect(self._handleReturnHome)
        self.arm_rais_but.clicked.connect(self._handle_arm_raise)
        self.ball_but.clicked.connect(self._handle_ball)
        self.run_but.clicked.connect(self._handle_run)
        self.smileButton.clicked.connect(self._handle_smile)
        self.staticFacesButton.clicked.connect(self._handle_static_faces)
#===================================================================================================
#                                                                                 H A N D L E R S

#___________________________________________________________________________________________________ _handleReturnHome
    def _handleReturnHome(self):
        self.mainWindow.setActiveWidget('home')

    def _handle_kick_but(self):
        self.mainWindow.setActiveWidget('kick')
        #cmds.setAttr( 'pSphere1.translateX', 10 )

    def _handle_arm_raise(self):
        self.mainWindow.setActiveWidget('arm_raise');

    def _handle_ball(self):
        self.mainWindow.setActiveWidget('ball');

    def _handle_run(self):
        self.mainWindow.setActiveWidget('run');

    def _handle_smile(self):
        self.mainWindow.setActiveWidget('smile');

    def _handle_static_faces(self):
        self.mainWindow.setActiveWidget('emotion');



