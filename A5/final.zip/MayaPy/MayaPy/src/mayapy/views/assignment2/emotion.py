# Run.py
# Lei Li

from pyglass.widgets.PyGlassWidget import PyGlassWidget
import nimble
from nimble import cmds

#___________________________________________________________________________________________________ Assignment2Widget
class emotion(PyGlassWidget):
    """A class for..."""

#===================================================================================================
#                                                                                       C L A S S

#___________________________________________________________________________________________________ __init__
    def __init__(self, parent, **kwargs):
        """Creates a new instance of Assignment2Widget."""
        super(emotion, self).__init__(parent, **kwargs)
        self.homeButton.clicked.connect(self._handle_home_but)
        self.surpriseButton.clicked.connect(self._handle_surprise_but)
        self.resetButton.clicked.connect(self._handle_reset_but)
        self.sadlyButton.clicked.connect(self._handle_sadly_but)





#===================================================================================================
#                                                                                 H A N D L E R S

    def _handle_home_but(self):
        self.mainWindow.setActiveWidget('home')

    def _handle_surprise_but(self):

        # mouth
        upMax = 0.15
        downMax = -upMax

        cmds.setAttr('mouth_up1.translateY',upMax)
        cmds.setAttr('mouth_up2.translateY',upMax)
        cmds.setAttr('mouth_up3.translateY',upMax)
        cmds.setAttr('mouth_up4.translateY',upMax)
        cmds.setAttr('mouth_up5.translateY',upMax)

        cmds.setAttr('mouth_down1.translateY',downMax)
        cmds.setAttr('mouth_down2.translateY',downMax)
        cmds.setAttr('mouth_down3.translateY',downMax)
        cmds.setAttr('mouth_down4.translateY',downMax)

        #eyes
        upMax = -0.05
        downMax = -upMax

        cmds.setAttr('eye_up1.translateY',upMax)
        cmds.setAttr('eye_up2.translateY',upMax)
        cmds.setAttr('eye_up3.translateY',upMax)
        cmds.setAttr('eye_down1.translateY',downMax)
        cmds.setAttr('eye_down2.translateY',downMax)
        cmds.setAttr('eye_down3.translateY',downMax)

        #eyebows
        x0 = -1.982
        y0 = -0.223
        z0 = -0.00396

        x1 = -1.84
        y1 = -0.104
        z1 = 0.0297

        y0Max = 0.2
        y1Max = 0.1


        cmds.setAttr('curve1.cv[0]',x0,y0Max+y0,z0)
        cmds.setAttr('curve1.cv[1]',x1,y1Max+y1,z1)

    def _handle_sadly_but(self):

        cmds.setAttr('mouth_up1.translateY',0.05)
        cmds.setAttr('mouth_up2.translateY',0.1)
        cmds.setAttr('mouth_up3.translateY',0.1)

        cmds.setAttr('high1.translateY',-0.03)
        cmds.setAttr('high2.translateY',-0.03)
        cmds.setAttr('high3.translateY',-0.03)

        cmds.setAttr('eye_up3.translateY',0.1)
        cmds.setAttr('eye_down3.translateY',-0.05)

        cmds.setAttr('eye_up2.translateY',0.1)
        cmds.setAttr('eye_down2.translateY',-0.05)

        cmds.setAttr('eye_up1.translateY',0.1)
        cmds.setAttr('eye_down1.translateY',-0.05)

        cmds.setAttr('eye_wide2.translateX',-0.05)
        cmds.setAttr('eye_wide2.translateY',-0.05)

        cmds.setAttr('eye_wide1.translateX',0.05)
        cmds.setAttr('eye_wide1.translateY',-0.05)

        cx = 0.05
        cy = -0.1

        cmds.setAttr('cluster10Handle.translateX',cx)
        cmds.setAttr('cluster10Handle.translateY',cy)

        cmds.setAttr('cluster11Handle.translateX',cx)
        cmds.setAttr('cluster11Handle.translateY',cy)


        cmds.setAttr('cluster13Handle.translateX',cx)
        cmds.setAttr('cluster13Handle.translateY',cy)


        cmds.setAttr('cluster14Handle.translateX',cx)
        cmds.setAttr('cluster14Handle.translateY',cy)

        cmds.setAttr('cluster15Handle.translateX',cx)
        cmds.setAttr('cluster15Handle.translateY',cy)


    def _handle_reset_but(self):
        Zero = 0

        cmds.setAttr('cluster10Handle.translateX',Zero)
        cmds.setAttr('cluster10Handle.translateY',Zero)
        cmds.setAttr('cluster10Handle.translateZ',Zero)

        cmds.setAttr('cluster11Handle.translateX',Zero)
        cmds.setAttr('cluster11Handle.translateY',Zero)
        cmds.setAttr('cluster11Handle.translateZ',Zero)

        cmds.setAttr('cluster13Handle.translateX',Zero)
        cmds.setAttr('cluster13Handle.translateY',Zero)
        cmds.setAttr('cluster13Handle.translateZ',Zero)

        cmds.setAttr('cluster14Handle.translateX',Zero)
        cmds.setAttr('cluster14Handle.translateY',Zero)
        cmds.setAttr('cluster14Handle.translateZ',Zero)

        cmds.setAttr('cluster15Handle.translateX',Zero)
        cmds.setAttr('cluster15Handle.translateY',Zero)
        cmds.setAttr('cluster15Handle.translateZ',Zero)

        cmds.setAttr('eye_wide1.translateX',Zero)
        cmds.setAttr('eye_wide1.translateY',Zero)
        cmds.setAttr('eye_wide1.translateZ',Zero)

        cmds.setAttr('eye_wide2.translateX',Zero)
        cmds.setAttr('eye_wide2.translateY',Zero)
        cmds.setAttr('eye_wide2.translateZ',Zero)

        cmds.setAttr('eye_down1.translateX',Zero)
        cmds.setAttr('eye_down1.translateY',Zero)
        cmds.setAttr('eye_down1.translateZ',Zero)

        cmds.setAttr('eye_up1.translateX',Zero)
        cmds.setAttr('eye_up1.translateY',Zero)
        cmds.setAttr('eye_up1.translateZ',Zero)

        cmds.setAttr('eye_down2.translateX',Zero)
        cmds.setAttr('eye_down2.translateY',Zero)
        cmds.setAttr('eye_down2.translateZ',Zero)

        cmds.setAttr('eye_up2.translateX',Zero)
        cmds.setAttr('eye_up2.translateY',Zero)
        cmds.setAttr('eye_up2.translateZ',Zero)

        cmds.setAttr('eye_down3.translateX',Zero)
        cmds.setAttr('eye_down3.translateY',Zero)
        cmds.setAttr('eye_down3.translateZ',Zero)

        cmds.setAttr('eye_up3.translateX',Zero)
        cmds.setAttr('eye_up3.translateY',Zero)
        cmds.setAttr('eye_up3.translateZ',Zero)

        cmds.setAttr('angry_eye1.translateX',Zero)
        cmds.setAttr('angry_eye1.translateY',Zero)
        cmds.setAttr('angry_eye1.translateZ',Zero)

        cmds.setAttr('angry_eye2.translateX',Zero)
        cmds.setAttr('angry_eye2.translateY',Zero)
        cmds.setAttr('angry_eye2.translateZ',Zero)

        cmds.setAttr('face_wide1.translateX',Zero)
        cmds.setAttr('face_wide1.translateY',Zero)
        cmds.setAttr('face_wide1.translateZ',Zero)

        cmds.setAttr('face_wide2.translateX',Zero)
        cmds.setAttr('face_wide2.translateY',Zero)
        cmds.setAttr('face_wide2.translateZ',Zero)

        cmds.setAttr('face_wide3.translateX',Zero)
        cmds.setAttr('face_wide3.translateY',Zero)
        cmds.setAttr('face_wide3.translateZ',Zero)

        cmds.setAttr('high1.translateX',Zero)
        cmds.setAttr('high1.translateY',Zero)
        cmds.setAttr('high1.translateZ',Zero)

        cmds.setAttr('high2.translateX',Zero)
        cmds.setAttr('high2.translateY',Zero)
        cmds.setAttr('high2.translateZ',Zero)

        cmds.setAttr('high3.translateX',Zero)
        cmds.setAttr('high3.translateY',Zero)
        cmds.setAttr('high3.translateZ',Zero)

        cmds.setAttr('nose_high1.translateX',Zero)
        cmds.setAttr('nose_high1.translateY',Zero)
        cmds.setAttr('nose_high1.translateZ',Zero)

        cmds.setAttr('nose_wide_high1.translateX',Zero)
        cmds.setAttr('nose_wide_high1.translateY',Zero)
        cmds.setAttr('nose_wide_high1.translateZ',Zero)

        cmds.setAttr('nose_up_high1.translateX',Zero)
        cmds.setAttr('nose_up_high1.translateY',Zero)
        cmds.setAttr('nose_up_high1.translateZ',Zero)

        cmds.setAttr('nose_wide_high2.translateX',Zero)
        cmds.setAttr('nose_wide_high2.translateY',Zero)
        cmds.setAttr('nose_wide_high2.translateZ',Zero)

        cmds.setAttr('chin1.translateX',Zero)
        cmds.setAttr('chin1.translateY',Zero)
        cmds.setAttr('chin1.translateZ',Zero)

        cmds.setAttr('chin2.translateX',Zero)
        cmds.setAttr('chin2.translateY',Zero)
        cmds.setAttr('chin2.translateZ',Zero)

        cmds.setAttr('chin3.translateX',Zero)
        cmds.setAttr('chin3.translateY',Zero)
        cmds.setAttr('chin3.translateZ',Zero)

        cmds.setAttr('chin4.translateX',Zero)
        cmds.setAttr('chin4.translateY',Zero)
        cmds.setAttr('chin4.translateZ',Zero)

        cmds.setAttr('mouth_up1.translateX',Zero)
        cmds.setAttr('mouth_up1.translateY',Zero)
        cmds.setAttr('mouth_up1.translateZ',Zero)

        cmds.setAttr('mouth_up2.translateX',Zero)
        cmds.setAttr('mouth_up2.translateY',Zero)
        cmds.setAttr('mouth_up2.translateZ',Zero)

        cmds.setAttr('mouth_up3.translateX',Zero)
        cmds.setAttr('mouth_up3.translateY',Zero)
        cmds.setAttr('mouth_up3.translateZ',Zero)

        cmds.setAttr('mouth_up4.translateX',Zero)
        cmds.setAttr('mouth_up4.translateY',Zero)
        cmds.setAttr('mouth_up4.translateZ',Zero)

        cmds.setAttr('mouth_up5.translateX',Zero)
        cmds.setAttr('mouth_up5.translateY',Zero)
        cmds.setAttr('mouth_up5.translateZ',Zero)

        cmds.setAttr('mouth_down1.translateX',Zero)
        cmds.setAttr('mouth_down1.translateY',Zero)
        cmds.setAttr('mouth_down1.translateZ',Zero)

        cmds.setAttr('mouth_down2.translateX',Zero)
        cmds.setAttr('mouth_down2.translateY',Zero)
        cmds.setAttr('mouth_down2.translateZ',Zero)

        cmds.setAttr('mouth_down3.translateX',Zero)
        cmds.setAttr('mouth_down3.translateY',Zero)
        cmds.setAttr('mouth_down3.translateZ',Zero)

        cmds.setAttr('mouth_down4.translateX',Zero)
        cmds.setAttr('mouth_down4.translateY',Zero)
        cmds.setAttr('mouth_down4.translateZ',Zero)

        x0 = -1.982
        y0 = -0.223
        z0 = -0.00396

        x1 = -1.84
        y1 = -0.104
        z1 = 0.0297

        x2 = -1.632
        y2 = -0.178
        z2 = -0.0822

        x3 = -1.524
        y3 = -0.221
        z3 = -0.32
        cmds.setAttr('curve1.cv[0]',x0,y0,z0)
        cmds.setAttr('curve1.cv[1]',x1,y1,z1)
        cmds.setAttr('curve1.cv[2]',x2,y2,z2)
        cmds.setAttr('curve1.cv[3]',x3,y3,z3)


